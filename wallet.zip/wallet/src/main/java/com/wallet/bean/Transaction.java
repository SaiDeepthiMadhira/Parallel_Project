package com.wallet.bean;

import java.time.LocalDate;
import java.util.HashMap;

public class Transaction {

	private String status;
	private String transaction_type;
	private String account;
	private String senderAcc;
	private String receiverAcc;
	private LocalDate date;
	private String amount;
	
	
	private static HashMap<String,Transaction> transactionMap = new HashMap<String,Transaction>();
	
	public static HashMap<String, Transaction> getTransactionMap(){
		return transactionMap;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSenderAcc() {
		return senderAcc;
	}

	public void setSenderAcc(String senderAcc) {
		this.senderAcc = senderAcc;
	}

	public String getReceiverAcc() {
		return receiverAcc;
	}

	public void setReceiverAcc(String receiverAcc) {
		this.receiverAcc = receiverAcc;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	
	
	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Transaction(String status, String transaction_type, String account, LocalDate date, String amount) {
		super();
		this.status = status;
		this.transaction_type = transaction_type;
		this.account = account;
		this.date = date;
		this.amount = amount;
		
		this.senderAcc = "";
		this.receiverAcc = "";
	}

	public Transaction(String status, String transaction_type, String senderAcc, String receiverAcc,
			LocalDate date, String amount) {
		super();
		this.status = status;
		this.transaction_type = transaction_type;
		this.senderAcc = senderAcc;
		this.receiverAcc = receiverAcc;
		this.date = date;
		this.amount = amount;
		
		this.account = "";
	}

	public Transaction() {
		super();
	}
	
	
	
}
